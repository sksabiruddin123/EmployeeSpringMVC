package springcrud.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Component;

import springcrud.model.Employee;

@Component
public class EmployeeDaoImp implements EmployeeDao{
	
    private HibernateTemplate hibernateTemplate;
	
	@Autowired
	public EmployeeDaoImp(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}

	@Override
	@Transactional
	public void save(Employee employee) {	
		hibernateTemplate.saveOrUpdate(employee);	
	}

	@Override
	public Employee findById(int id) {
		
		return hibernateTemplate.get(Employee.class, id);
	}

	@Override
	public List<Employee> findAll() {
		
		return hibernateTemplate.loadAll(Employee.class);
	}

	@Override
	@Transactional
	public void update(Employee employee) {
		hibernateTemplate.update(employee);	
	}

	@Override
	@Transactional
	public void delete(int id) {
		Employee employee=findById(id);
		if(employee != null) {
			hibernateTemplate.delete(employee);
		}
	}

}
