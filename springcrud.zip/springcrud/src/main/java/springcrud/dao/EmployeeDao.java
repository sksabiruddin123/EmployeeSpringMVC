package springcrud.dao;

import java.util.List;

import springcrud.model.Employee;

public interface EmployeeDao {

	//Create
	void save(Employee employee);
	
	//Read
	Employee findById(int id);
	
	//Read All
	List<Employee> findAll();
	
	//Update
	void update(Employee employee);
	
	//Delete
	void delete(int id);
}
