package springcrud.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.view.RedirectView;

import springcrud.model.Employee;
import springcrud.service.EmployeeService;

@Controller
public class HomeController {
	
	@Autowired
	private EmployeeService employeeService;
	
	@RequestMapping("/")
	public String home(Model m) {
		
	 List<Employee> allEmployees = employeeService.getAllEmployees();
	 m.addAttribute("employee",allEmployees);
		
		return "index";
	}
	
	@RequestMapping("/add_employee")
	public String addingEmployee(Model m) {
		
		m.addAttribute("title" ,"Add Employee");
		
		return "add_employee_form";
	}
	
	//Handle Employee Form
	@RequestMapping(value="/handle-employee" ,method=RequestMethod.POST)
	public RedirectView handleEmployee(@ModelAttribute Employee employee, HttpServletRequest request) {
		
	System.out.println(employee);
	
	employeeService.addEmployee(employee);
		
	RedirectView redirectView=new RedirectView();
	redirectView.setUrl(request.getContextPath()+"/");
		
    return 	redirectView;	
	}
	
	//Delete Employee
	@RequestMapping(value="/delete/{employeeId}")
	public RedirectView deleteEmployee(@PathVariable("employeeId") int employeeId, HttpServletRequest request) {
		
		this.employeeService.deleteEmployee(employeeId);
		
		RedirectView redirectView=new RedirectView();
		redirectView.setUrl(request.getContextPath()+"/");
			
	    return 	redirectView;
	}
	
	
	//Update Employee
	@RequestMapping("/update/{employeeId}")
	public String updateForm(@PathVariable("employeeId") int eId,Model model) {
		
		Employee employee =employeeService.getEmployeeById(eId);
		model.addAttribute("employee", employee);
		
		
		return "update_form";			
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
