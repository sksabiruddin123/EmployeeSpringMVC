package springcrud.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import springcrud.dao.EmployeeDao;
import springcrud.model.Employee;

@Service
@Transactional
public class EmployeeServiceImp implements EmployeeService{

	@Autowired
    private EmployeeDao employeeDAO;

    @Override
    public void addEmployee(Employee employee) {
        employeeDAO.save(employee);
    }

    @Override
    public void updateEmployee(Employee employee) {
        employeeDAO.update(employee);
    }

    @Override
    public Employee getEmployeeById(int id) {
        return employeeDAO.findById(id);
    }

    @Override
    public void deleteEmployee(int id) {
        employeeDAO.delete(id);
    }

    @Override
    public List<Employee> getAllEmployees() {
        return employeeDAO.findAll();
    }

}
